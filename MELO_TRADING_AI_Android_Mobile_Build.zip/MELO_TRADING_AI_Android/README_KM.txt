MELO TRADING AI — Android project with cloud APK build

អ្នកអាចប្រើទូរស័ព្ទដើម្បីបញ្ជូនគម្រោងទៅ GitHub ហើយ GitHub Actions នឹង build APK នៅលើ cloud។
មិនចាំបាច់ដំឡើង Android Studio លើទូរស័ព្ទទេ។

ជំហាន:
1. បង្កើតគណនី GitHub ឥតគិតថ្លៃ ប្រសិនបើមិនទាន់មាន។
2. បង្កើត repository ថ្មី (ឧ. melo-trading-ai) និងដាក់ Public ឬ Private។
3. Upload មាតិកាទាំងអស់ក្នុង folder គម្រោងនេះទៅ repository ដោយរក្សា folder structure ដដែល។ ត្រូវរួមបញ្ចូល .github/workflows/build-apk.yml។
4. ចូល tab Actions ក្នុង repository ហើយជ្រើស workflow "Build MELO TRADING AI APK"។ ប្រសិនបើមិនរត់ដោយស្វ័យប្រវត្តិ ចុច Run workflow។
5. រង់ចាំរហូត workflow បញ្ចប់ដោយសញ្ញាបៃតង។
6. បើក run ដែលបានបញ្ចប់ ហើយនៅផ្នែក Artifacts ចុច MELO-TRADING-AI-debug-apk ដើម្បីទាញយក ZIP ដែលមាន app-debug.apk។
7. Extract ZIP នោះ រួចដំឡើង app-debug.apk លើ Android។

ចំណាំ:
- អាចធ្វើបានតាម browser លើទូរស័ព្ទ ប៉ុន្តែការបង្ហោះ folder structure អាចពិបាកបន្តិច។
- APK នេះជា debug APK សម្រាប់សាកល្បង មិនមែន signed release APK សម្រាប់ Play Store ទេ។
- ក្រាហ្វ TradingView ត្រូវការអ៊ីនធឺណិត។
- AI BUY/SELL ស្វ័យប្រវត្តិមិនទាន់បានភ្ជាប់ទេ; ត្រូវការទិន្នន័យទីផ្សារមានអាជ្ញាបណ្ណ និង backend។
